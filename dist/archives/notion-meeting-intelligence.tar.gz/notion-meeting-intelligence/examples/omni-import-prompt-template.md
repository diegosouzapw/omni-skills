# Imported Prompt Template

```text
Use @notion-meeting-intelligence to handle <task>.
Start with the workflow playbook and support-pack index.
Load only the upstream files needed for <goal> and keep provenance visible in the result.
```
